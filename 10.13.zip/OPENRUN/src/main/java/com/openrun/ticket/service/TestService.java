package com.openrun.ticket.service;

import java.util.List;

import com.openrun.ticket.bean.TestBean;

public interface TestService {
	public List<TestBean> test() throws Exception;
}
