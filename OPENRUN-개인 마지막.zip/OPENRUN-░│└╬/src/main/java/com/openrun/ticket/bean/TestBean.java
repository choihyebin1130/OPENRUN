package com.openrun.ticket.bean;

import java.sql.Date;

public class TestBean {

	private int test_INT;
	private String test_TEXT;
	private Date test_DATE;
	private double test_DOUBLE;
	public int getTest_INT() {
		return test_INT;
	}
	public void setTest_INT(int test_INT) {
		this.test_INT = test_INT;
	}
	public String getTest_TEXT() {
		return test_TEXT;
	}
	public void setTest_TEXT(String test_TEXT) {
		this.test_TEXT = test_TEXT;
	}
	public Date getTest_DATE() {
		return test_DATE;
	}
	public void setTest_DATE(Date test_DATE) {
		this.test_DATE = test_DATE;
	}
	public double getTest_DOUBLE() {
		return test_DOUBLE;
	}
	public void setTest_DOUBLE(double test_DOUBLE) {
		this.test_DOUBLE = test_DOUBLE;
	}
	
	
}
