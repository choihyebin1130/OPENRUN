package com.openrun.ticket.service;

import org.springframework.stereotype.Service;

import com.openrun.ticket.Dao.SellerDao;
import com.openrun.ticket.Vo.SellerVo;

@Service
public class SellerServiceImpl implements SellerService{
	
	public void setSellerDao(SellerDao sellerDao){
	      this.dao = sellerDao;
	   }
	private SellerDao dao;
	
	@Override
	public void insertSeller(SellerVo sellerVo) throws Exception{
		dao.insertSeller(sellerVo);
	}
	@Override
	public boolean isIdAvailable(String s_id) {
        int count = dao.idCheck(s_id);
        return count == 0;
    }
	@Override
	public SellerVo Login(SellerVo sellerVo) {
		return dao.Login(sellerVo);
	}
	@Override
	public SellerVo findIdCheck(SellerVo sellerVo) {
		return dao.findIdCheck(sellerVo);
	}
	@Override
	public SellerVo findPwCheck(SellerVo sellerVo) {
		return dao.findPwCheck(sellerVo);
	}
	@Override
	public String pwChange(SellerVo sellerVo){
		return dao.pwChange(sellerVo);
	}
	
}
