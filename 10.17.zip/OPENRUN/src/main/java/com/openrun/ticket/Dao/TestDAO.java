package com.openrun.ticket.Dao;

import java.util.List;

import com.openrun.ticket.bean.TestBean;

public interface TestDAO {
	public List<TestBean> test() throws Exception;
}
