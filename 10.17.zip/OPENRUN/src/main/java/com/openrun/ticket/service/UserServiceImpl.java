package com.openrun.ticket.service;

import java.util.List;

import org.springframework.stereotype.Service;
import com.openrun.ticket.Dao.UserDao;
import com.openrun.ticket.Vo.UserVo;

@Service
public class UserServiceImpl implements UserService {
	public void setUserDao(UserDao userDao){
	      this.dao = userDao;
	   }
	private UserDao dao;
	
	@Override
	public List<UserVo> user() throws Exception {
		// TODO Auto-generated method stub
		return dao.user();
	}
	@Override
	 public void insertUser(UserVo userVo) throws Exception{
		dao.insertUser(userVo);
	}
	@Override
	public boolean isIdAvailable(String u_id) {
        int count = dao.idCheck(u_id);
        return count == 0;
    }
	@Override
	public UserVo Login(UserVo userVo) {
		return dao.Login(userVo);
	}
	@Override
	public UserVo findIdCheck(UserVo userVo) {
		return dao.findIdCheck(userVo);
	}
	@Override
	public UserVo findPwCheck(UserVo userVo) {
		return dao.findPwCheck(userVo);
	}
	@Override
	public String pwChange(UserVo userVo){
		return dao.pwChange(userVo);
	}

	
}
