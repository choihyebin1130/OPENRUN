package com.openrun.ticket.Dao;

import java.util.Map;

public interface ReservationDao {
	public int insertReservation(Map<String,Object> params);
}
