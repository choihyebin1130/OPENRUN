package com.openrun.ticket.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.openrun.ticket.Vo.UserVo;
import com.openrun.ticket.service.UserService;

@Controller
public class MainController {
	
	private UserService service;
	
	@Autowired
    public MainController(UserService userService) {
        this.service = userService;
    }
	
	@RequestMapping(value= {"/"} , method = RequestMethod.GET)
	public String joinMember(Model model) throws Exception {
		List<UserVo> list = new ArrayList<>(); // 빈 리스트를 초기화하여 NullPointerException을 방지
	    try {
	        list = service.user();
	    } catch (Exception e) {
	        // 예외 처리 코드 추가
	        e.printStackTrace(); // 또는 로그에 기록하거나 적절한 처리를 수행
	    }

		model.addAttribute("useTest", list);
		
		return "joinMember";
	}

	
	@GetMapping("/loginForm")
	public String loginForm(){
		System.out.println("MainController / loginForm");
		
		String nextPage = "common/loginForm";
		return nextPage;
	}
}
