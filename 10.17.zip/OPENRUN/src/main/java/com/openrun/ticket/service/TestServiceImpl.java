package com.openrun.ticket.service;

import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import com.openrun.ticket.Dao.TestDAO;
import com.openrun.ticket.bean.TestBean;

@Service
public class TestServiceImpl implements TestService {

	  @Inject
	  private TestDAO dao;

	  @Override
	  public List<TestBean> test() throws Exception {
	    return dao.test();
	  }

}

