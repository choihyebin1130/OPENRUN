package com.openrun.ticket.service;

import com.openrun.ticket.Vo.SellerVo;

public interface SellerService {
	 public void insertSeller(SellerVo sellerVo) throws Exception;
	 public boolean isIdAvailable(String s_id);
	 public SellerVo Login(SellerVo sellerVo);
	 public SellerVo findIdCheck(SellerVo sellerVo);
	 public SellerVo findPwCheck(SellerVo sellerVo);
	 public String pwChange(SellerVo sellerVo);
}
