package com.openrun.ticket.Dao;

public class ReservationDaoImpl implements ReservationDao{

}
