package com.openrun.ticket.Dao;

import com.openrun.ticket.Vo.SellerVo;

public interface SellerDao {
	public void insertSeller(SellerVo sellerVo) throws Exception;
	public int idCheck(String s_id);
	public SellerVo Login(SellerVo sellerVo);
	public SellerVo findIdCheck(SellerVo sellerVo);
	public SellerVo findPwCheck(SellerVo sellerVo);
	public String pwChange(SellerVo sellerVo);
}
