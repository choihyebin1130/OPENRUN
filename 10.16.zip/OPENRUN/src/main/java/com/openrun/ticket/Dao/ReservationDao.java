package com.openrun.ticket.Dao;

public interface ReservationDao {

}
