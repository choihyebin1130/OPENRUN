package com.openrun.ticket.service;

import org.springframework.stereotype.Service;

@Service
public class ReservationServiceImpl implements ReservationService{

}
