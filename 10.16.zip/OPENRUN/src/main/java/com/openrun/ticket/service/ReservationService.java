package com.openrun.ticket.service;

public interface ReservationService {

}
