package com.openrun.ticket.Dao;

import java.util.List;

import com.openrun.ticket.Vo.UserVo;

public interface UserDao {
	public List<UserVo> user() throws Exception;
	public void insertUser(UserVo userVo) throws Exception;
	public int idCheck(String u_id);
	public UserVo Login(UserVo userVo);
	public UserVo findIdCheck(UserVo userVo);
	public UserVo findPwCheck(UserVo userVo);
	public String pwChange(UserVo userVo);
}
