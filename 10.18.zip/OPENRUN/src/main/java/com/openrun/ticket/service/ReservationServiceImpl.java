package com.openrun.ticket.service;


import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.openrun.ticket.Dao.ReservationDao;

@Service
public class ReservationServiceImpl implements ReservationService{
	
	 private ReservationDao reservationDao;

	 @Autowired
	 public void setReservationDao(ReservationDao reservationDao) {
		 this.reservationDao = reservationDao;
	 }
	 
	 @Override
	 public int insertReservation(Map<String,Object> params) {
		 return reservationDao.insertReservation(params);
	 }
}
