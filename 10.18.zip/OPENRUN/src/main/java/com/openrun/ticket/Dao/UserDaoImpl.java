package com.openrun.ticket.Dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Repository;

import com.openrun.ticket.Vo.UserVo;

@Repository
@Primary
public class UserDaoImpl implements UserDao{
	
	public void setSqlSession(SqlSession sqlSession) {
		this.sqlSession = sqlSession;
	}
	
	private static final String namespace="com.openrun.ticket.userMapper";
	 
	 private SqlSession sqlSession;
	 
	 @Override
		public List<UserVo> user() throws Exception{
			// TODO Auto-generated method stub
			return sqlSession.selectList(namespace +".user");
	 }
	 @Override
	    public void insertUser(UserVo userVo) throws Exception {
	        sqlSession.insert(namespace + ".insertUser", userVo);
	 }
	 @Override
	 public int idCheck(String u_id) {
	        return sqlSession.selectOne(namespace + ".idCheck", u_id);
	 }
	 @Override
	 public UserVo Login(UserVo userVo) {
	        return sqlSession.selectOne(namespace + ".login", userVo);
	 }
	 @Override
	 public UserVo findIdCheck(UserVo userVo) {
			 return sqlSession.selectOne(namespace + ".findIdCheck", userVo);
		   
	 }
	 @Override
	 public UserVo findPwCheck(UserVo userVo) {
		 return sqlSession.selectOne(namespace + ".findPwCheck", userVo);
	 }
	 
	 @Override
	 public String pwChange(UserVo userVo) {
		 return sqlSession.selectOne(namespace + ".pwChange", userVo);
 
	 }
}
