package com.openrun.ticket.service;

import java.util.Map;

public interface ReservationService {
	public int insertReservation(Map<String,Object> params);
}
