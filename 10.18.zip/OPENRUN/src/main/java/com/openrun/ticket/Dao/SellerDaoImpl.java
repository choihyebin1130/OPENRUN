package com.openrun.ticket.Dao;

import org.apache.ibatis.session.SqlSession;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Repository;

import com.openrun.ticket.Vo.SellerVo;

@Repository
@Primary
public class SellerDaoImpl implements SellerDao{
	public void setSqlSession(SqlSession sqlSession) {
		this.sqlSession = sqlSession;
	}
	
	private static final String namespace="com.openrun.ticket.sellerMapper";
	
	 private SqlSession sqlSession;
	 
	 @Override
	 public void insertSeller(SellerVo sellerVo) throws Exception{
	        sqlSession.insert(namespace + ".insertSeller", sellerVo);
	 }
	 @Override
	 public int idCheck(String s_id) {
		    return sqlSession.selectOne(namespace + ".idCheck", s_id);
	 }
	 @Override
	 public SellerVo Login(SellerVo sellerVo) {
	        return sqlSession.selectOne(namespace + ".login", sellerVo);
	 }
	 @Override
	 public SellerVo findIdCheck(SellerVo sellerVo) {
	
		 	SellerVo result = sqlSession.selectOne(namespace + ".findIdCheck", sellerVo);
		    
		    if (result != null) {
		        // 사용자 정보를 찾았을 때 로그로 확인
		        System.out.println("사용자 정보를 찾았습니다");
		    } else {
		        // 사용자 정보를 찾지 못했을 때 로그로 확인
		        System.out.println("사용자 정보를 찾지 못했습니다.");
		    }

		    return result;
	 }
	@Override
	 public SellerVo findPwCheck(SellerVo sellerVo) {
	
		SellerVo result = sqlSession.selectOne(namespace + ".findPwCheck", sellerVo);
		    
		    if (result != null) {
		        // 사용자 정보를 찾았을 때 로그로 확인
		        System.out.println("사용자 정보를 찾았습니다 : " + result.getS_id());
		        System.out.println("사용자 정보를 찾았습니다 : " + result.getS_business_name());
		    } else {
		        // 사용자 정보를 찾지 못했을 때 로그로 확인
		        System.out.println("사용자 정보를 찾지 못했습니다.");
		    }

		    return result;
	 }
	 @Override
	 public String pwChange(SellerVo sellerVo) {
		
		 return sqlSession.selectOne(namespace + ".pwChange", sellerVo);
		 
		 
	 }
}
